package com.example.demo.helper.enums;

public enum PaymentEnum {
    CARD,
    CASH,
    TRANSFER
}
