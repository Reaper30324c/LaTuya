package com.example.demo.helper.enums;

public enum RequestEnum {
    AWAITING,
    ON_TRACK,
    DELIVERED
}
