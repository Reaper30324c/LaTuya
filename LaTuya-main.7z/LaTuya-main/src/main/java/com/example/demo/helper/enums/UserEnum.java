package com.example.demo.helper.enums;

public enum UserEnum {
    CLIENT,
    DELIVERYMAN

}
