package com.example.demo.helper.enums;

public enum PaymentStatusEnum {
    FAILED,
    COMPLETED,
    AWAITING
}
