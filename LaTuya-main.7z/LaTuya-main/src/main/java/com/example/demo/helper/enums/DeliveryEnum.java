package com.example.demo.helper.enums;

public enum DeliveryEnum {
    ASSIGNED,
    DELIVERED,
    ON_WAY
}
